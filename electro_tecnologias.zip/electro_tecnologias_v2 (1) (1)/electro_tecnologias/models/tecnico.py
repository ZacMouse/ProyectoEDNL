from abc import ABC, abstractmethod
from models.estructuras import ColaFIFO   # reemplaza deque


class Tecnico(ABC):
    # Clase base para todos los técnicos.
    # No se puede usar directamente — hay que usar una de las subclases.

    def __init__(self, nombre):
        self.nombre      = nombre
        self.cola        = ColaFIFO()   # antes era deque() — ahora es nuestra propia cola
        self.cola_espera = ColaFIFO()   # igual aquí

    @property
    @abstractmethod
    def nivel(self):
        pass

    @property
    @abstractmethod
    def prioridad(self):
        pass

    def tiene_trabajo(self):
        return not self.cola.esta_vacia()

    def __repr__(self):
        return f"{self.nivel}: {self.nombre} (cola={len(self.cola)}, espera={len(self.cola_espera)})"


class TecnicoEspecialista(Tecnico):
    # Atiende daños graves (P1 — emergencia)

    def __init__(self, nombre):
        super().__init__(nombre)

    @property
    def nivel(self):
        return "Especialista"

    @property
    def prioridad(self):
        return 1


class TecnicoIntermedio(Tecnico):
    # Atiende fallas funcionales y cambio de piezas (P2)

    def __init__(self, nombre):
        super().__init__(nombre)

    @property
    def nivel(self):
        return "Intermedio"

    @property
    def prioridad(self):
        return 2


class TecnicoJunior(Tecnico):
    # Atiende optimización, actualización y estética (P3)

    def __init__(self, nombre):
        super().__init__(nombre)

    @property
    def nivel(self):
        return "Junior"

    @property
    def prioridad(self):
        return 3
