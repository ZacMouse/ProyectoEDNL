import uuid
from datetime import datetime


# Opciones de prioridad que el usuario puede seleccionar en el formulario
PRIORIDADES = {
    "P1 - Alta (Emergencia)":   1,
    "P2 - Media (Funcional)":   2,
    "P3 - Baja (Optimización)": 3,
}

# Texto legible para cada estado interno del dispositivo
ESTADOS = {
    "EN_COLA":    "En cola de llegada",
    "ASIGNADO":   "Asignado a técnico",
    "EN_ESPERA":  "Esperando repuestos",
    "COMPLETADO": "Reparación completada",
}


class Dispositivo:
    # Representa un equipo que un cliente trae a reparar.
    # Se crea al momento del registro y viaja por todo el sistema.

    def __init__(self, nombre_cliente, telefono, direccion,
                 marca, modelo, daño, prioridad_str):

        # ID único de 8 caracteres generado automáticamente
        self.id = str(uuid.uuid4())[:8].upper()

        self.nombre_cliente  = nombre_cliente
        self.telefono        = telefono
        self.direccion       = direccion
        self.marca           = marca
        self.modelo          = modelo
        self.daño            = daño
        self.prioridad_str   = prioridad_str
        self.prioridad       = PRIORIDADES[prioridad_str]

        self.estado           = "EN_COLA"
        self.tecnico_asignado = None
        self.fecha_registro   = datetime.now().strftime("%d/%m/%Y %H:%M")

        # Estos campos se llenan cuando el técnico termina la reparación
        self.diagnostico      = ""
        self.nota_reporte     = ""
        self.fecha_completado = ""

    def marcar_completado(self, diagnostico, nota):
        # El técnico llama a este método al terminar el trabajo
        self.diagnostico      = diagnostico
        self.nota_reporte     = nota
        self.estado           = "COMPLETADO"
        self.fecha_completado = datetime.now().strftime("%d/%m/%Y %H:%M")

    def __repr__(self):
        return f"[{self.id}] {self.marca} {self.modelo} — {self.nombre_cliente}"
