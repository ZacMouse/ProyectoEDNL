
class Nodo:
    # Nodo de la cola y la pila, guarda un dato y apunta al siguiente nodo
    def __init__(self, dato):
        self.dato      = dato      
        self.siguiente = None      

    def __repr__(self):
        return f"Nodo({self.dato})"


class ColaFIFO:
    # Cola de primero en entrar, primero en salir.
    def __init__(self):
        self.cabeza = None   # primer nodo (el que sale primero)
        self.cola   = None   # último nodo (el que entró último)
        self.tamaño = 0       

    def agregar(self, dato):
        # Crea un nodo nuevo y lo pone al final de la cola
        nuevo_nodo = Nodo(dato)

        if self.cola is None:
            # La cola está vacía — el nuevo nodo es cabeza y cola al mismo tiempo
            self.cabeza = nuevo_nodo
            self.cola   = nuevo_nodo
        else:
            # Ya hay elementos — el último nodo apunta al nuevo
            self.cola.siguiente = nuevo_nodo   # el anterior último apunta al nuevo
            self.cola           = nuevo_nodo   # el nuevo se convierte en el último

        self.tamaño += 1

    def sacar(self):
        # Saca y retorna el dato de la cabeza (el primero que llegó)
        if self.esta_vacia():
            return None

        dato_cabeza     = self.cabeza.dato     # guardamos el dato antes de perderlo
        self.cabeza     = self.cabeza.siguiente  # la cabeza avanza al siguiente nodo

        if self.cabeza is None:
            # Si ya no hay nadie, la cola también queda en None
            self.cola = None

        self.tamaño -= 1
        return dato_cabeza

    def eliminar(self, dato):
        # Elimina un nodo específico de cualquier posición de la cola
        if self.esta_vacia():
            return False

        # Caso especial: el que hay que eliminar es la cabeza
        if self.cabeza.dato == dato:
            self.sacar()
            return True

        # Recorremos buscando el nodo anterior al que queremos eliminar
        nodo_actual = self.cabeza
        while nodo_actual.siguiente is not None:
            if nodo_actual.siguiente.dato == dato:
                # Encontramos el nodo — lo saltamos en la cadena
                if nodo_actual.siguiente == self.cola:
                    # Era el último — actualizamos la cola
                    self.cola = nodo_actual
                nodo_actual.siguiente = nodo_actual.siguiente.siguiente
                self.tamaño -= 1
                return True
            nodo_actual = nodo_actual.siguiente

        return False

    def contiene(self, dato):
        # Retorna True si el dato está en la cola
        nodo_actual = self.cabeza
        while nodo_actual is not None:
            if nodo_actual.dato == dato:
                return True
            nodo_actual = nodo_actual.siguiente
        return False

    def esta_vacia(self):
        return self.cabeza is None

    def como_lista(self):
        # Retorna todos los elementos como lista (para mostrar en la tabla)
        resultado   = []
        nodo_actual = self.cabeza
        while nodo_actual is not None:
            resultado.append(nodo_actual.dato)
            nodo_actual = nodo_actual.siguiente
        return resultado

    def __len__(self):
        return self.tamaño

    def __iter__(self):
        # Permite usar la cola en un for directamente
        nodo_actual = self.cabeza
        while nodo_actual is not None:
            yield nodo_actual.dato
            nodo_actual = nodo_actual.siguiente

    def __repr__(self):
        elementos = " → ".join(str(n.dato) for n in self._nodos())
        return f"ColaFIFO: cabeza → [{elementos}] → None"

    def _nodos(self):
        nodo_actual = self.cabeza
        while nodo_actual is not None:
            yield nodo_actual
            nodo_actual = nodo_actual.siguiente


class PilaLIFO:
    # Pila de último en entrar, primero en salir.
    def __init__(self):
        self.cima   = None   # nodo en la parte de arriba (el que sale primero)
        self.tamaño = 0

    def apilar(self, dato):
        # Crea un nodo nuevo y lo pone encima de la pila
        nuevo_nodo          = Nodo(dato)
        nuevo_nodo.siguiente = self.cima   # el nuevo apunta al que era la cima
        self.cima           = nuevo_nodo   # el nuevo se convierte en la cima
        self.tamaño         += 1

    def desapilar(self):
        # Saca y retorna el dato de la cima
        if self.esta_vacia():
            return None

        dato_cima  = self.cima.dato        # guardamos el dato
        self.cima  = self.cima.siguiente   # la cima baja un nivel
        self.tamaño -= 1
        return dato_cima

    def ver_cima(self):
        # Retorna el dato de la cima sin sacarlo
        if self.esta_vacia():
            return None
        return self.cima.dato

    def esta_vacia(self):
        return self.cima is None

    def como_lista_invertida(self):
        # Retorna los elementos de cima a base (orden LIFO para mostrar en pantalla)
        resultado   = []
        nodo_actual = self.cima
        while nodo_actual is not None:
            resultado.append(nodo_actual.dato)
            nodo_actual = nodo_actual.siguiente
        return resultado

    def __len__(self):
        return self.tamaño

    def __iter__(self):
        nodo_actual = self.cima
        while nodo_actual is not None:
            yield nodo_actual.dato
            nodo_actual = nodo_actual.siguiente

    def __repr__(self):
        elementos = " → ".join(str(n.dato) for n in self._nodos())
        return f"PilaLIFO: cima → [{elementos}] → None"

    def _nodos(self):
        nodo_actual = self.cima
        while nodo_actual is not None:
            yield nodo_actual
            nodo_actual = nodo_actual.siguiente
