from .dispositivo import Dispositivo, PRIORIDADES, ESTADOS
from .tecnico import Tecnico, TecnicoEspecialista, TecnicoIntermedio, TecnicoJunior
from .estructuras import Nodo, ColaFIFO, PilaLIFO
