from models.dispositivo import Dispositivo
from models.tecnico import TecnicoEspecialista, TecnicoIntermedio, TecnicoJunior, Tecnico
from models.estructuras import ColaFIFO, PilaLIFO   # nuestras estructuras propias


class SistemaReparacion:
    # Núcleo del programa. Maneja todas las estructuras y el flujo de dispositivos.
    #
    # Estructuras usadas:
    #   ColaFIFO  cola_llegada        → cola global de registro
    #   ColaFIFO  tecnico.cola        → cola de trabajo por técnico
    #   ColaFIFO  tecnico.cola_espera → dispositivos esperando repuestos
    #   PilaLIFO  pila_reportes       → historial de reparaciones terminadas
    #   dict      todos               → acceso rápido por ID

    def __init__(self):
        self.cola_llegada  = ColaFIFO()   # antes: deque()
        self.pila_reportes = PilaLIFO()   # antes: []
        self.todos         = {}

        self.tecnicos = [
            TecnicoEspecialista("Carlos Mendoza"),
            TecnicoIntermedio("Luis Herrera"),
            TecnicoJunior("Andrés Ruiz"),
        ]

    def registrar_dispositivo(self, nombre_cliente, telefono, direccion,
                               marca, modelo, daño, prioridad_str):
        # Crea el dispositivo y lo mete al final de la cola de llegada
        dispositivo = Dispositivo(nombre_cliente, telefono, direccion,
                                  marca, modelo, daño, prioridad_str)
        self.cola_llegada.agregar(dispositivo)      # antes: .append()
        self.todos[dispositivo.id] = dispositivo
        return dispositivo

    def clasificar_y_asignar(self):
        # Saca los dispositivos de la cola global (FIFO)
        # y los manda al técnico correspondiente según prioridad
        procesados = []
        while not self.cola_llegada.esta_vacia():   # antes: while self.cola_llegada
            dispositivo = self.cola_llegada.sacar() # antes: .popleft()
            tecnico     = self._tecnico_por_prioridad(dispositivo.prioridad)
            dispositivo.tecnico_asignado = tecnico.nombre
            dispositivo.estado           = "ASIGNADO"
            tecnico.cola.agregar(dispositivo)       # antes: .append()
            procesados.append(dispositivo)
        return procesados

    def enviar_a_espera(self, dispositivo):
        # El dispositivo necesita repuestos — sale de la cola activa
        tecnico = self._buscar_tecnico(dispositivo.tecnico_asignado)
        if tecnico and tecnico.cola.contiene(dispositivo):  # antes: "in tecnico.cola"
            tecnico.cola.eliminar(dispositivo)              # antes: .remove()
            dispositivo.estado = "EN_ESPERA"
            tecnico.cola_espera.agregar(dispositivo)        # antes: .append()

    def repuestos_llegaron(self, dispositivo):
        # Llegaron los repuestos — vuelve al final de la cola activa
        tecnico = self._buscar_tecnico(dispositivo.tecnico_asignado)
        if tecnico and tecnico.cola_espera.contiene(dispositivo):
            tecnico.cola_espera.eliminar(dispositivo)       # antes: .remove()
            dispositivo.estado = "ASIGNADO"
            tecnico.cola.agregar(dispositivo)               # vuelve al final

    def completar_reparacion(self, dispositivo, diagnostico, nota):
        # Cierra la reparación y apila el reporte (LIFO)
        tecnico = self._buscar_tecnico(dispositivo.tecnico_asignado)
        if tecnico and tecnico.cola.contiene(dispositivo):
            tecnico.cola.eliminar(dispositivo)
        dispositivo.marcar_completado(diagnostico, nota)
        self.pila_reportes.apilar(dispositivo)              # antes: .append()

    def reportes_recientes(self):
        # Devuelve los reportes de más reciente a más antiguo (LIFO)
        return self.pila_reportes.como_lista_invertida()    # antes: list(reversed(...))

    def buscar_dispositivo(self, identificador):
        return self.todos.get(identificador)

    def _tecnico_por_prioridad(self, prioridad):
        for tecnico in self.tecnicos:
            if tecnico.prioridad == prioridad:
                return tecnico
        return self.tecnicos[-1]

    def _buscar_tecnico(self, nombre):
        for tecnico in self.tecnicos:
            if tecnico.nombre == nombre:
                return tecnico
        return None
