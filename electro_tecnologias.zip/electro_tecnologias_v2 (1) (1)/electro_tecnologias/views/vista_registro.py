import tkinter as tk
from tkinter import messagebox
from models.dispositivo import PRIORIDADES
from views.estilos import (
    BG, BG_CARD, TEAL, CORAL,
    P1_CLR, P2_CLR, P3_CLR,
    TEXT_DARK, TEXT_MID, TEXT_LIGHT, BORDER,
    FONT_TITULO, FONT_PEQUEÑO,
    boton, tarjeta, campo_texto, campo_multilinea,
    tabla, frame_con_scroll, titulo_seccion
)


class VistaRegistro(tk.Frame):
    # Pestaña de registro. Tiene el formulario a la izquierda
    # y la cola de llegada (FIFO) a la derecha.

    def __init__(self, padre, sistema, al_asignar):
        super().__init__(padre, bg=BG)
        self.sistema    = sistema
        self.al_asignar = al_asignar  # callback para refrescar VistaAsignacion
        self.campos     = {}          # nombre_campo -> widget
        self._construir()

    def _construir(self):
        _, interior = frame_con_scroll(self)

        # --- Panel izquierdo: formulario ---
        panel_izq = tarjeta(interior, padx=28, pady=24)
        panel_izq.pack(side="left", fill="y", padx=(20, 10), pady=20)

        tk.Label(panel_izq, text="📋  Registrar Dispositivo",
                 font=FONT_TITULO, bg=BG_CARD, fg=TEXT_DARK
                 ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        self._agregar_campos(panel_izq)
        self._agregar_radio_prioridad(panel_izq, fila_inicio=13)

        boton(panel_izq, "  ✚  Registrar Dispositivo", self._registrar
              ).grid(row=16, column=0, columnspan=2,
                     sticky="ew", pady=(20, 0), ipady=4)

        # --- Panel derecho: cola de llegada ---
        panel_der = tarjeta(interior, padx=18, pady=20)
        panel_der.pack(side="right", fill="both", expand=True,
                       padx=(0, 20), pady=20)

        fila_encab = tk.Frame(panel_der, bg=BG_CARD)
        fila_encab.pack(fill="x", pady=(0, 12))

        titulo_seccion(fila_encab, "Cola de Llegada  (FIFO)").pack(side="left")

        self.contador_cola = tk.Label(fila_encab, text="0 equipos",
                                      font=("Segoe UI", 9, "bold"),
                                      bg=TEAL, fg="white", padx=10, pady=3)
        self.contador_cola.pack(side="right")

        tk.Label(panel_der,
                 text="Los equipos se atienden en orden de llegada.",
                 font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_LIGHT,
                 wraplength=500, justify="left"
                 ).pack(anchor="w", pady=(0, 10))

        columnas = ("ID", "Cliente", "Equipo", "Daño", "Prioridad", "Hora")
        self.tabla_llegada = tabla(panel_der, columnas, alto=10)

        boton(panel_der, "  ▶  Clasificar y Asignar a Técnico",
              self._clasificar, color=CORAL
              ).pack(fill="x", pady=(14, 0), ipady=4)

        tk.Label(panel_der,
                 text="Cada equipo será enviado al técnico según su prioridad.",
                 font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_LIGHT,
                 wraplength=500
                 ).pack(anchor="w", pady=(6, 0))

    def _agregar_campos(self, padre):
        # Sección datos del cliente
        tk.Label(padre, text="DATOS DEL CLIENTE",
                 font=("Segoe UI", 8, "bold"), bg=BG_CARD, fg=TEXT_LIGHT
                 ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(0, 6))

        campos_cliente = [
            ("Nombre completo", "nombre"),
            ("Teléfono",        "telefono"),
            ("Dirección",       "direccion"),
        ]
        for indice, (etiqueta, clave) in enumerate(campos_cliente):
            fila = indice + 2
            tk.Label(padre, text=etiqueta, font=FONT_PEQUEÑO,
                     bg=BG_CARD, fg=TEXT_MID, anchor="w"
                     ).grid(row=fila, column=0, sticky="w", pady=3, padx=(0, 12))
            widget = campo_texto(padre, ancho=26)
            widget.grid(row=fila, column=1, sticky="ew", pady=3)
            self.campos[clave] = widget

        # Separador
        tk.Frame(padre, bg=BORDER, height=1
                 ).grid(row=5, column=0, columnspan=2, sticky="ew", pady=5)

        # Sección datos del equipo
        tk.Label(padre, text="DATOS DEL EQUIPO",
                 font=("Segoe UI", 8, "bold"), bg=BG_CARD, fg=TEXT_LIGHT
                 ).grid(row=6, column=0, columnspan=2, sticky="w", pady=(0, 6))

        campos_equipo = [
            ("Marca",               "marca"),
            ("Modelo",              "modelo"),
            ("Descripción del daño","daño"),
        ]
        for indice, (etiqueta, clave) in enumerate(campos_equipo):
            fila = indice + 7
            tk.Label(padre, text=etiqueta, font=FONT_PEQUEÑO,
                     bg=BG_CARD, fg=TEXT_MID, anchor="w"
                     ).grid(row=fila, column=0, sticky="w", pady=3, padx=(0, 12))
            if clave == "daño":
                widget = campo_multilinea(padre, ancho=26, alto=3)
            else:
                widget = campo_texto(padre, ancho=26)
            widget.grid(row=fila, column=1, sticky="ew", pady=3)
            self.campos[clave] = widget

        # Separador
        tk.Frame(padre, bg=BORDER, height=1
                 ).grid(row=11, column=0, columnspan=2, sticky="ew", pady=5)

    def _agregar_radio_prioridad(self, padre, fila_inicio):
        tk.Label(padre, text="NIVEL DE PRIORIDAD",
                 font=("Segoe UI", 8, "bold"), bg=BG_CARD, fg=TEXT_LIGHT
                 ).grid(row=fila_inicio, column=0, columnspan=2,
                        sticky="w", pady=(0, 4))

        self.prioridad_seleccionada = tk.StringVar(value=list(PRIORIDADES.keys())[0])

        colores      = [P1_CLR, P2_CLR, P3_CLR]
        descripciones = [
            "Daño grave / urgente",
            "Cambio de piezas / falla funcional",
            "Optimización / estética",
        ]

        for indice, (clave, _) in enumerate(PRIORIDADES.items()):
            fila = tk.Frame(padre, bg=BG_CARD)
            fila.grid(row=fila_inicio + 1 + indice, column=0,
                      columnspan=2, sticky="w", pady=1)

            tk.Label(fila, text="●", bg=BG_CARD, fg=colores[indice],
                     font=("Segoe UI", 12)).pack(side="left", padx=(0, 6))

            tk.Radiobutton(fila, text=clave,
                           variable=self.prioridad_seleccionada,
                           value=clave, bg=BG_CARD, fg=TEXT_DARK,
                           selectcolor=BG_CARD, activebackground=BG_CARD,
                           font=FONT_PEQUEÑO, cursor="hand2"
                           ).pack(side="left")

            tk.Label(fila, text=f"— {descripciones[indice]}",
                     font=("Segoe UI", 8), bg=BG_CARD, fg=TEXT_LIGHT
                     ).pack(side="left", padx=(4, 0))

    def _registrar(self):
        nombre   = self.campos["nombre"].get().strip()
        telefono = self.campos["telefono"].get().strip()
        direccion = self.campos["direccion"].get().strip()
        marca    = self.campos["marca"].get().strip()
        modelo   = self.campos["modelo"].get().strip()
        daño     = self.campos["daño"].get("1.0", "end").strip()
        prioridad = self.prioridad_seleccionada.get()

        if not all([nombre, telefono, direccion, marca, modelo, daño]):
            messagebox.showwarning("Campos incompletos",
                                   "Por favor completa todos los campos.")
            return

        dispositivo = self.sistema.registrar_dispositivo(
            nombre, telefono, direccion, marca, modelo, daño, prioridad)

        self.refrescar_cola()
        self._limpiar_formulario()
        messagebox.showinfo("Registro exitoso",
                            f"Dispositivo registrado\nID: {dispositivo.id}\n"
                            f"Prioridad: {prioridad}")

    def _clasificar(self):
        if self.sistema.cola_llegada.esta_vacia():
            messagebox.showinfo("Sin dispositivos",
                                "No hay equipos en la cola de llegada.")
            return

        procesados = self.sistema.clasificar_y_asignar()
        self.refrescar_cola()
        self.al_asignar()
        messagebox.showinfo("Asignación completada",
                            f"{len(procesados)} equipo(s) asignado(s).\n"
                            f"Revisa la pestaña Asignación.")

    def refrescar_cola(self):
        for fila in self.tabla_llegada.get_children():
            self.tabla_llegada.delete(fila)

        for dispositivo in self.sistema.cola_llegada:
            etiqueta = f"p{dispositivo.prioridad}"
            texto_daño = (dispositivo.daño[:35] + "…"
                          if len(dispositivo.daño) > 35 else dispositivo.daño)
            self.tabla_llegada.insert("", "end", values=(
                dispositivo.id,
                dispositivo.nombre_cliente,
                f"{dispositivo.marca} {dispositivo.modelo}",
                texto_daño,
                dispositivo.prioridad_str,
                dispositivo.fecha_registro
            ), tags=(etiqueta,))

        self.tabla_llegada.tag_configure("p1", foreground=P1_CLR)
        self.tabla_llegada.tag_configure("p2", foreground=P2_CLR)
        self.tabla_llegada.tag_configure("p3", foreground=P3_CLR)

        cantidad = len(self.sistema.cola_llegada)
        self.contador_cola.config(text=f"{cantidad} equipo(s)")

    def _limpiar_formulario(self):
        for clave, widget in self.campos.items():
            if isinstance(widget, tk.Text):
                widget.delete("1.0", "end")
            else:
                widget.delete(0, "end")
        self.prioridad_seleccionada.set(list(PRIORIDADES.keys())[0])
