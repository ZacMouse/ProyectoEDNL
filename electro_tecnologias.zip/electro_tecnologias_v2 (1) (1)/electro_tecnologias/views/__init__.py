from .app import App
from .vista_registro import VistaRegistro
from .vista_asignacion import VistaAsignacion
from .vista_reportes import VistaReportes
