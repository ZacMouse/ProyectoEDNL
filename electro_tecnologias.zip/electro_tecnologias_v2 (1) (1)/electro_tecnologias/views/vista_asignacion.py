import tkinter as tk
from tkinter import messagebox
from models.dispositivo import ESTADOS
from views.estilos import (
    BG, BG_CARD, TEAL, CORAL, GOLD,
    P1_CLR, P2_CLR, P3_CLR,
    TEXT_DARK, TEXT_MID, TEXT_LIGHT, BORDER,
    FONT_TITULO, FONT_PEQUEÑO,
    color_prioridad, fondo_prioridad,
    boton, tarjeta, campo_multilinea,
    tabla, frame_con_scroll_2d
)


class VistaAsignacion(tk.Frame):
    # Pestaña de técnicos. Muestra las colas de trabajo y espera
    # de cada técnico, y los botones para gestionar cada dispositivo.

    def __init__(self, padre, sistema, al_completar):
        super().__init__(padre, bg=BG)
        self.sistema      = sistema
        self.al_completar = al_completar  # callback para refrescar VistaReportes
        self.widgets_tec  = {}            # nombre_tecnico -> (tabla_activa, tabla_espera)
        self._construir()

    def _construir(self):
        # Encabezado fijo (no hace scroll)
        encabezado = tk.Frame(self, bg=BG, padx=20, pady=12)
        encabezado.pack(fill="x")

        tk.Label(encabezado, text="🔧  Panel de Técnicos",
                 font=FONT_TITULO, bg=BG, fg=TEXT_DARK).pack(side="left")

        boton(encabezado, "↺  Actualizar", self.refrescar,
              color=BG_CARD, color_texto=TEAL).pack(side="right")

        tk.Label(encabezado,
                 text="Selecciona un equipo y usa los botones para gestionar su estado.",
                 font=("Segoe UI", 9), bg=BG, fg=TEXT_LIGHT
                 ).pack(side="left", padx=16)

        # Paneles de técnicos dentro del scroll 2D
        _, interior = frame_con_scroll_2d(self)

        contenedor = tk.Frame(interior, bg=BG)
        contenedor.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        for tecnico in self.sistema.tecnicos:
            self._construir_panel_tecnico(contenedor, tecnico)

    def _construir_panel_tecnico(self, padre, tecnico):
        color_acento = color_prioridad(tecnico.prioridad)
        color_fondo  = fondo_prioridad(tecnico.prioridad)

        # Tarjeta del técnico
        tarjeta_ext = tarjeta(padre, padx=0, pady=0)
        tarjeta_ext.pack(side="left", fill="both", expand=True, padx=8, pady=8)

        # Header con color de prioridad
        encabezado = tk.Frame(tarjeta_ext, bg=color_fondo, padx=16, pady=12)
        encabezado.pack(fill="x")

        tk.Frame(encabezado, bg=color_acento, width=4
                 ).pack(side="left", fill="y", padx=(0, 12))

        info = tk.Frame(encabezado, bg=color_fondo)
        info.pack(side="left", fill="both", expand=True)

        tk.Label(info, text=tecnico.nivel.upper(),
                 font=FONT_PEQUEÑO, bg=color_acento, fg="white",
                 padx=8, pady=2).pack(anchor="w")

        tk.Label(info, text=tecnico.nombre,
                 font=("Segoe UI", 11, "bold"),
                 bg=color_fondo, fg=TEXT_DARK).pack(anchor="w", pady=(4, 0))

        tk.Label(info, text=f"Atiende prioridad P{tecnico.prioridad}",
                 font=("Segoe UI", 8), bg=color_fondo,
                 fg=TEXT_MID).pack(anchor="w")

        # Cuerpo de la tarjeta
        cuerpo = tk.Frame(tarjeta_ext, bg=BG_CARD, padx=14, pady=12)
        cuerpo.pack(fill="both", expand=True)

        tk.Label(cuerpo, text="Cola de trabajo:",
                 font=FONT_PEQUEÑO, bg=BG_CARD, fg=TEXT_MID
                 ).pack(anchor="w", pady=(0, 4))

        columnas = ("ID", "Cliente", "Equipo", "Estado")
        tabla_activa = tabla(cuerpo, columnas, alto=5)

        tk.Label(cuerpo, text="⏳  Esperando repuestos:",
                 font=FONT_PEQUEÑO, bg=BG_CARD, fg=GOLD
                 ).pack(anchor="w", pady=(12, 4))

        tabla_espera = tabla(cuerpo, columnas, alto=3)

        # Botones de acción
        fila_botones = tk.Frame(cuerpo, bg=BG_CARD)
        fila_botones.pack(fill="x", pady=(12, 0))

        boton(fila_botones, "⏳ A espera",
              lambda tec=tecnico: self._enviar_a_espera(tec),
              color=GOLD, color_texto="white").pack(side="left", padx=(0, 6))

        boton(fila_botones, "✅ Repuestos OK",
              lambda tec=tecnico: self._confirmar_repuestos(tec),
              color=P3_CLR, color_texto="white").pack(side="left", padx=(0, 6))

        boton(fila_botones, "🏁 Completar",
              lambda tec=tecnico: self._completar(tec),
              color=TEAL, color_texto="white").pack(side="left")

        self.widgets_tec[tecnico.nombre] = (tabla_activa, tabla_espera)

    def _obtener_seleccionado(self, vista_arbol):
        seleccion = vista_arbol.selection()
        if not seleccion:
            messagebox.showwarning("Selección requerida",
                                   "Selecciona un equipo de la lista.")
            return None
        identificador = vista_arbol.item(seleccion[0])["values"][0]
        return self.sistema.buscar_dispositivo(identificador)

    def _enviar_a_espera(self, tecnico):
        tabla_activa, _ = self.widgets_tec[tecnico.nombre]
        dispositivo = self._obtener_seleccionado(tabla_activa)
        if dispositivo:
            self.sistema.enviar_a_espera(dispositivo)
            self.refrescar()
            messagebox.showinfo("Cola de espera",
                                f"'{dispositivo}'\nfue enviado a espera de repuestos.")

    def _confirmar_repuestos(self, tecnico):
        _, tabla_espera = self.widgets_tec[tecnico.nombre]
        dispositivo = self._obtener_seleccionado(tabla_espera)
        if dispositivo:
            self.sistema.repuestos_llegaron(dispositivo)
            self.refrescar()
            messagebox.showinfo("Repuestos disponibles",
                                f"'{dispositivo}'\nvolvió al final de la cola de trabajo.")

    def _completar(self, tecnico):
        tabla_activa, _ = self.widgets_tec[tecnico.nombre]
        dispositivo = self._obtener_seleccionado(tabla_activa)
        if dispositivo:
            VentanaDiagnostico(self, self.sistema, dispositivo,
                               al_confirmar=self._post_completar)

    def _post_completar(self):
        self.refrescar()
        self.al_completar()

    def refrescar(self):
        for tecnico in self.sistema.tecnicos:
            tabla_activa, tabla_espera = self.widgets_tec[tecnico.nombre]

            for fila in tabla_activa.get_children():
                tabla_activa.delete(fila)
            for dispositivo in tecnico.cola:
                tabla_activa.insert("", "end", values=(
                    dispositivo.id,
                    dispositivo.nombre_cliente,
                    f"{dispositivo.marca} {dispositivo.modelo}",
                    ESTADOS[dispositivo.estado]
                ))

            for fila in tabla_espera.get_children():
                tabla_espera.delete(fila)
            for dispositivo in tecnico.cola_espera:
                tabla_espera.insert("", "end", values=(
                    dispositivo.id,
                    dispositivo.nombre_cliente,
                    f"{dispositivo.marca} {dispositivo.modelo}",
                    ESTADOS[dispositivo.estado]
                ), tags=("espera",))
            tabla_espera.tag_configure("espera", foreground=GOLD)


class VentanaDiagnostico(tk.Toplevel):
    # Ventana emergente donde el técnico escribe el diagnóstico
    # y la nota para el cliente antes de cerrar la reparación.

    def __init__(self, padre, sistema, dispositivo, al_confirmar):
        super().__init__(padre)
        self.sistema       = sistema
        self.dispositivo   = dispositivo
        self.al_confirmar  = al_confirmar

        self.title(f"Completar — {dispositivo}")
        self.geometry("500x480")
        self.configure(bg=BG_CARD)
        self.resizable(False, True)
        self.grab_set()
        self._construir()

    def _construir(self):
        formulario = tarjeta(self, padx=28, pady=24)
        formulario.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(formulario, text="🏁  Diagnóstico Final",
                 font=("Segoe UI", 15, "bold"),
                 bg=BG_CARD, fg=TEXT_DARK).pack(anchor="w", pady=(0, 4))

        tk.Label(formulario,
                 text=f"{self.dispositivo.marca} {self.dispositivo.modelo}"
                      f"  —  Cliente: {self.dispositivo.nombre_cliente}",
                 font=FONT_PEQUEÑO, bg=BG_CARD, fg=TEXT_MID
                 ).pack(anchor="w", pady=(0, 16))

        tk.Label(formulario, text="Diagnóstico técnico:",
                 font=FONT_PEQUEÑO, bg=BG_CARD, fg=TEXT_MID, anchor="w"
                 ).pack(fill="x", pady=(0, 4))
        self.campo_diagnostico = campo_multilinea(formulario, ancho=50, alto=4)
        self.campo_diagnostico.pack(fill="x", pady=(0, 12))

        tk.Label(formulario, text="Nota para el cliente:",
                 font=FONT_PEQUEÑO, bg=BG_CARD, fg=TEXT_MID, anchor="w"
                 ).pack(fill="x", pady=(0, 4))
        self.campo_nota = campo_multilinea(formulario, ancho=50, alto=4)
        self.campo_nota.pack(fill="x", pady=(0, 20))

        boton(formulario, "  📤  Enviar Reporte al Cliente",
              self._confirmar, color=TEAL).pack(fill="x", ipady=4)

    def _confirmar(self):
        diagnostico = self.campo_diagnostico.get("1.0", "end").strip()
        nota        = self.campo_nota.get("1.0", "end").strip()

        if not diagnostico or not nota:
            messagebox.showwarning("Campos requeridos",
                                   "Completa el diagnóstico y la nota.",
                                   parent=self)
            return

        self.sistema.completar_reparacion(self.dispositivo, diagnostico, nota)
        self.destroy()
        self.al_confirmar()
        messagebox.showinfo("Reparación completada",
                            f"Reporte enviado correctamente.\n\n"
                            f"Cliente: {self.dispositivo.nombre_cliente}\n"
                            f"Puede pasar a recoger su equipo.")
