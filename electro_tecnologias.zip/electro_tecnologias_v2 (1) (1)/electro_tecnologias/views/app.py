import tkinter as tk
from tkinter import ttk
from sistema.sistema_reparacion import SistemaReparacion
from views.vista_registro import VistaRegistro
from views.vista_asignacion import VistaAsignacion
from views.vista_reportes import VistaReportes
from views.estilos import (
    BG, BG_CARD, TEAL, TEAL_LT, BORDER,
    TEXT_DARK, TEXT_LIGHT,
    FONT_TITULO, FONT_PEQUEÑO
)


class App(tk.Tk):
    # Ventana principal. Crea el sistema y ensambla las tres pestañas.

    def __init__(self):
        super().__init__()
        self.sistema = SistemaReparacion()

        self.title("Electro Tecnologías — Sistema de Reparaciones")
        self.geometry("1300x800")
        self.minsize(1100, 700)
        self.configure(bg=BG)

        self._construir_encabezado()
        self._construir_pestanas()

    def _construir_encabezado(self):
        encabezado = tk.Frame(self, bg="white")
        encabezado.pack(fill="x")

        # Línea de acento superior
        tk.Canvas(encabezado, height=4, bg=TEAL,
                  highlightthickness=0).pack(fill="x")

        barra = tk.Frame(encabezado, bg="white", padx=24, pady=14)
        barra.pack(fill="x")

        # Logo + nombre
        lado_izq = tk.Frame(barra, bg="white")
        lado_izq.pack(side="left")

        tk.Label(lado_izq, text="⚡",
                 font=("Segoe UI", 22), bg="white", fg=TEAL
                 ).pack(side="left", padx=(0, 10))

        titulos = tk.Frame(lado_izq, bg="white")
        titulos.pack(side="left")

        tk.Label(titulos, text="Electro Tecnologías",
                 font=("Segoe UI", 16, "bold"),
                 bg="white", fg=TEXT_DARK).pack(anchor="w")

        tk.Label(titulos, text="Sistema de Asignación de Reparaciones",
                 font=("Segoe UI", 9), bg="white",
                 fg=TEXT_LIGHT).pack(anchor="w")

        # Badge de tecnología
        tk.Label(barra, text="🐍 Python  +  tkinter",
                 font=("Segoe UI", 9), bg=TEAL_LT,
                 fg=TEAL, padx=10, pady=4
                 ).pack(side="right")

        tk.Frame(encabezado, bg=BORDER, height=1).pack(fill="x")

    def _construir_pestanas(self):
        estilo = ttk.Style(self)
        estilo.theme_use("default")
        estilo.configure("TNotebook",
                         background="white", borderwidth=0,
                         tabmargins=[0, 0, 0, 0])
        estilo.configure("TNotebook.Tab",
                         background=BG, foreground=TEXT_LIGHT,
                         font=("Segoe UI", 10, "bold"),
                         padding=[20, 10], borderwidth=0)
        estilo.map("TNotebook.Tab",
                   background=[("selected", "white")],
                   foreground=[("selected", TEAL)])

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        # Se crean en este orden porque cada vista necesita el callback de la siguiente
        vista_reportes   = VistaReportes(notebook, self.sistema)
        vista_asignacion = VistaAsignacion(notebook, self.sistema,
                                           al_completar=vista_reportes.refrescar)
        vista_registro   = VistaRegistro(notebook, self.sistema,
                                         al_asignar=vista_asignacion.refrescar)

        notebook.add(vista_registro,   text="  📋  Registro  ")
        notebook.add(vista_asignacion, text="  🔧  Asignación  ")
        notebook.add(vista_reportes,   text="  📊  Reportes  ")
