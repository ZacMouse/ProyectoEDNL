import tkinter as tk
from views.estilos import (
    BG, BG_CARD, TEAL, CORAL,
    P1_CLR, P2_CLR, P3_CLR,
    TEXT_DARK, TEXT_MID, TEXT_LIGHT,
    FONT_TITULO, FONT_CUERPO, FONT_PEQUEÑO,
    boton, tarjeta, tabla,
    frame_con_scroll, titulo_seccion
)


class VistaReportes(tk.Frame):
    # Pestaña de historial. Muestra las reparaciones completadas
    # en orden LIFO (la más reciente aparece primero).

    def __init__(self, padre, sistema):
        super().__init__(padre, bg=BG)
        self.sistema = sistema
        self._construir()

    def _construir(self):
        # Encabezado fijo
        encabezado = tk.Frame(self, bg=BG, padx=20, pady=12)
        encabezado.pack(fill="x")

        tk.Label(encabezado, text="📊  Historial de Reportes",
                 font=FONT_TITULO, bg=BG, fg=TEXT_DARK).pack(side="left")

        boton(encabezado, "↺  Actualizar", self.refrescar,
              color=BG_CARD, color_texto=TEAL).pack(side="right")

        tk.Label(encabezado,
                 text="Los reportes más recientes aparecen primero (LIFO).",
                 font=("Segoe UI", 9), bg=BG, fg=TEXT_LIGHT
                 ).pack(side="left", padx=16)

        # Contenido con scroll
        _, interior = frame_con_scroll(self)

        # Tarjeta de la tabla
        tarjeta_tabla = tarjeta(interior, padx=18, pady=16)
        tarjeta_tabla.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        titulo_seccion(tarjeta_tabla, "Reparaciones Completadas"
                       ).pack(anchor="w", pady=(0, 10))

        columnas = ("ID", "Cliente", "Teléfono", "Equipo",
                    "Técnico", "Prioridad", "Diagnóstico", "Nota", "Fecha")
        self.tabla_reportes = tabla(tarjeta_tabla, columnas, alto=12)
        self.tabla_reportes.bind("<<TreeviewSelect>>", self._mostrar_detalle)

        # Tarjeta de detalle
        tarjeta_detalle = tarjeta(interior, padx=20, pady=16)
        tarjeta_detalle.pack(fill="x", padx=20, pady=(0, 16))

        titulo_seccion(tarjeta_detalle, "Detalle del Reporte", CORAL
                       ).pack(anchor="w", pady=(0, 10))

        self.etiqueta_detalle = tk.Label(
            tarjeta_detalle,
            text="Selecciona un reporte para ver el detalle completo.",
            font=FONT_CUERPO, bg=BG_CARD, fg=TEXT_LIGHT,
            justify="left", wraplength=1000, anchor="w"
        )
        self.etiqueta_detalle.pack(anchor="w")

    def refrescar(self):
        for fila in self.tabla_reportes.get_children():
            self.tabla_reportes.delete(fila)

        for dispositivo in self.sistema.reportes_recientes():
            texto_diag = (dispositivo.diagnostico[:40] + "…"
                          if len(dispositivo.diagnostico) > 40
                          else dispositivo.diagnostico)
            texto_nota = (dispositivo.nota_reporte[:40] + "…"
                          if len(dispositivo.nota_reporte) > 40
                          else dispositivo.nota_reporte)

            self.tabla_reportes.insert("", "end", values=(
                dispositivo.id,
                dispositivo.nombre_cliente,
                dispositivo.telefono,
                f"{dispositivo.marca} {dispositivo.modelo}",
                dispositivo.tecnico_asignado,
                dispositivo.prioridad_str,
                texto_diag,
                texto_nota,
                dispositivo.fecha_completado,
            ), tags=(f"p{dispositivo.prioridad}",))

        self.tabla_reportes.tag_configure("p1", foreground=P1_CLR)
        self.tabla_reportes.tag_configure("p2", foreground=P2_CLR)
        self.tabla_reportes.tag_configure("p3", foreground=P3_CLR)

    def _mostrar_detalle(self, _evento):
        seleccion = self.tabla_reportes.selection()
        if not seleccion:
            return

        identificador = self.tabla_reportes.item(seleccion[0])["values"][0]
        dispositivo   = self.sistema.buscar_dispositivo(identificador)
        if not dispositivo:
            return

        texto = (
            f"ID: {dispositivo.id}   |   Cliente: {dispositivo.nombre_cliente}"
            f"   |   Tel: {dispositivo.telefono}   |   Dir: {dispositivo.direccion}\n"
            f"Equipo: {dispositivo.marca} {dispositivo.modelo}"
            f"   |   Técnico: {dispositivo.tecnico_asignado}"
            f"   |   Prioridad: {dispositivo.prioridad_str}\n\n"
            f"Daño reportado:      {dispositivo.daño}\n"
            f"Diagnóstico técnico: {dispositivo.diagnostico}\n"
            f"Nota al cliente:     {dispositivo.nota_reporte}\n"
            f"Fecha de entrega:    {dispositivo.fecha_completado}"
        )
        self.etiqueta_detalle.config(text=texto, fg=TEXT_DARK)
