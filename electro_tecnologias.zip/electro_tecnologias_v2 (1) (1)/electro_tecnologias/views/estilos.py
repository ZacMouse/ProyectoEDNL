import tkinter as tk
from tkinter import ttk


# --- Colores ---
BG        = "#EEF2F7"   # fondo principal
BG_CARD   = "#FFFFFF"   # fondo de tarjetas
BG_INPUT  = "#F5F8FB"   # fondo de campos de texto

TEAL      = "#1DB5A8"   # color principal
TEAL_LT   = "#E8FAF8"   # teal muy claro (selección de tablas)
CORAL     = "#FF6B6B"   # acciones secundarias / alertas
GOLD      = "#F4A435"   # advertencias / prioridad media

P1_CLR    = "#FF6B6B"   # prioridad alta
P1_BG     = "#FFF0F0"
P2_CLR    = "#F4A435"   # prioridad media
P2_BG     = "#FFF8EC"
P3_CLR    = "#1DB5A8"   # prioridad baja
P3_BG     = "#E8FAF8"

TEXT_DARK  = "#1C2B3A"
TEXT_MID   = "#5C6F82"
TEXT_LIGHT = "#9AAEC0"
BORDER     = "#DDE6EF"
BORDER_FOC = "#1DB5A8"

# --- Fuentes ---
FONT_TITULO  = ("Segoe UI", 15, "bold")
FONT_ENCAB   = ("Segoe UI", 11, "bold")
FONT_CUERPO  = ("Segoe UI", 10)
FONT_PEQUEÑO = ("Segoe UI", 9)
FONT_BADGE   = ("Segoe UI", 8, "bold")


def color_prioridad(prioridad):
    return {1: P1_CLR, 2: P2_CLR, 3: P3_CLR}.get(prioridad, TEXT_LIGHT)


def fondo_prioridad(prioridad):
    return {1: P1_BG, 2: P2_BG, 3: P3_BG}.get(prioridad, BG)


def _aclarar(color_hex, cantidad=20):
    # Aclara un color sumando 'cantidad' a cada canal RGB (para hover)
    rojo  = min(255, int(color_hex[1:3], 16) + cantidad)
    verde = min(255, int(color_hex[3:5], 16) + cantidad)
    azul  = min(255, int(color_hex[5:7], 16) + cantidad)
    return f"#{rojo:02x}{verde:02x}{azul:02x}"


def boton(padre, texto, comando, color=TEAL, color_texto="#FFFFFF", **kw):
    # Botón sin borde con efecto hover suave
    btn = tk.Button(
        padre, text=texto, command=comando,
        bg=color, fg=color_texto,
        font=FONT_ENCAB, relief="flat",
        cursor="hand2", padx=16, pady=8,
        activebackground=_aclarar(color),
        activeforeground=color_texto,
        **kw
    )
    btn.bind("<Enter>", lambda e: btn.config(bg=_aclarar(color)))
    btn.bind("<Leave>", lambda e: btn.config(bg=color))
    return btn


def tarjeta(padre, padx=20, pady=16, **kw):
    # Frame estilo tarjeta: fondo blanco con borde suave
    return tk.Frame(
        padre, bg=BG_CARD,
        padx=padx, pady=pady,
        highlightthickness=1,
        highlightbackground=BORDER,
        **kw
    )


def campo_texto(padre, ancho=28, **kw):
    # Entry con borde de foco en TEAL
    return tk.Entry(
        padre, width=ancho,
        bg=BG_INPUT, fg=TEXT_DARK,
        font=FONT_CUERPO,
        insertbackground=TEAL,
        relief="flat",
        highlightthickness=2,
        highlightbackground=BORDER,
        highlightcolor=BORDER_FOC,
        **kw
    )


def campo_multilinea(padre, ancho=28, alto=3, **kw):
    # Text multilínea con el mismo estilo que campo_texto
    return tk.Text(
        padre, width=ancho, height=alto,
        bg=BG_INPUT, fg=TEXT_DARK,
        font=FONT_CUERPO,
        insertbackground=TEAL,
        relief="flat",
        highlightthickness=2,
        highlightbackground=BORDER,
        highlightcolor=BORDER_FOC,
        padx=8, pady=6,
        **kw
    )


def tabla(padre, columnas, alto=8):
    # Treeview con estilo claro y scrollbar incluida
    estilo = ttk.Style()
    estilo.configure("Moderna.Treeview",
                     background=BG_CARD, foreground=TEXT_DARK,
                     fieldbackground=BG_CARD,
                     rowheight=28, font=FONT_PEQUEÑO, borderwidth=0)
    estilo.configure("Moderna.Treeview.Heading",
                     background=TEAL, foreground="#FFFFFF",
                     font=("Segoe UI", 9, "bold"),
                     relief="flat", padding=6)
    estilo.map("Moderna.Treeview",
               background=[("selected", TEAL_LT)],
               foreground=[("selected", TEXT_DARK)])

    contenedor = tk.Frame(padre, bg=BG_CARD,
                          highlightthickness=1,
                          highlightbackground=BORDER)
    contenedor.pack(fill="both", expand=True)

    vista_arbol = ttk.Treeview(contenedor, columns=columnas,
                                show="headings", height=alto,
                                style="Moderna.Treeview")
    barra = ttk.Scrollbar(contenedor, orient="vertical",
                          command=vista_arbol.yview)
    vista_arbol.configure(yscrollcommand=barra.set)

    for columna in columnas:
        if columna == "ID":
            ancho = 60
        elif columna in ("Estado", "Prioridad", "Fecha", "Teléfono"):
            ancho = 115
        else:
            ancho = 140
        vista_arbol.heading(columna, text=columna)
        vista_arbol.column(columna, width=ancho, minwidth=40)

    vista_arbol.pack(side="left", fill="both", expand=True)
    barra.pack(side="right", fill="y")
    return vista_arbol


def frame_con_scroll(padre, fondo=BG):
    # Frame con scroll vertical. Retorna (canvas, interior).
    # Agrega tus widgets dentro de 'interior'.
    contenedor = tk.Frame(padre, bg=fondo)
    contenedor.pack(fill="both", expand=True)

    barra_v = ttk.Scrollbar(contenedor, orient="vertical")
    barra_v.pack(side="right", fill="y")

    canvas = tk.Canvas(contenedor, bg=fondo, highlightthickness=0,
                       yscrollcommand=barra_v.set)
    canvas.pack(side="left", fill="both", expand=True)
    barra_v.config(command=canvas.yview)

    interior = tk.Frame(canvas, bg=fondo)
    id_ventana = canvas.create_window((0, 0), window=interior, anchor="nw")

    def al_redimensionar_interior(evento):
        canvas.configure(scrollregion=canvas.bbox("all"))
        canvas.itemconfig(id_ventana, width=canvas.winfo_width())

    def al_redimensionar_canvas(evento):
        canvas.itemconfig(id_ventana, width=evento.width)

    interior.bind("<Configure>", al_redimensionar_interior)
    canvas.bind("<Configure>", al_redimensionar_canvas)
    canvas.bind_all("<MouseWheel>",
                    lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

    return canvas, interior


def frame_con_scroll_2d(padre, fondo=BG):
    # Frame con scroll vertical Y horizontal.
    # Úsalo cuando el contenido puede ser más ancho que la ventana.
    contenedor = tk.Frame(padre, bg=fondo)
    contenedor.pack(fill="both", expand=True)

    barra_v = ttk.Scrollbar(contenedor, orient="vertical")
    barra_h = ttk.Scrollbar(contenedor, orient="horizontal")
    barra_v.pack(side="right", fill="y")
    barra_h.pack(side="bottom", fill="x")

    canvas = tk.Canvas(contenedor, bg=fondo, highlightthickness=0,
                       yscrollcommand=barra_v.set,
                       xscrollcommand=barra_h.set)
    canvas.pack(side="left", fill="both", expand=True)
    barra_v.config(command=canvas.yview)
    barra_h.config(command=canvas.xview)

    interior = tk.Frame(canvas, bg=fondo)
    canvas.create_window((0, 0), window=interior, anchor="nw")

    interior.bind("<Configure>",
                  lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    canvas.bind_all("<MouseWheel>",
                    lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))
    canvas.bind_all("<Shift-MouseWheel>",
                    lambda e: canvas.xview_scroll(int(-1 * (e.delta / 120)), "units"))

    return canvas, interior


def titulo_seccion(padre, texto, color_acento=TEAL):
    # Encabezado con barra de color a la izquierda: |  Texto
    fila = tk.Frame(padre, bg=BG_CARD)
    tk.Canvas(fila, width=4, height=24, bg=color_acento,
              highlightthickness=0).pack(side="left", padx=(0, 10))
    tk.Label(fila, text=texto, font=FONT_ENCAB,
             bg=BG_CARD, fg=TEXT_DARK).pack(side="left")
    return fila
